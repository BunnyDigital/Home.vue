app.component('product-display', {
  props: {
    premium: {
      type: Boolean,
      required: true
    }
  },
  template:
    /*html*/
    `

  <script src="https://kit.fontawesome.com/81c2c05f29.js" crossorigin="anonymous"></script>
  <nav class="navbar">
    <h3 class="logo">Logo</h3>
  
    <label for="toggler" class="icon"><i class="fas fa-bars"></i></label>
    <input type="checkbox" id="toggler" />
    <div class="links-wrapper active">
      <div class="backdrop"></div>
      <label for="toggler" class="close-btn"><i class="fas fa-times"></i></label>
      <ul class="links">
        <li><a href="#">Find Dealer</a></li>
        <li><a href="#">Sell My Vehicle</a></li>
        <li><a href="#">Become a Dealer</a></li>
      </ul>
    </div>
    <button></button>
  </nav>iv>
  </div>

  <div class="container">
   <div class="sec1">
    <div class="menubar">
      <div class="bar1"></div>
      <div class="bar2"></div>
      <div class="bar3"></div>
    </div>
  <br>
  
    <div class="circle">
      <div class="shoephoto">
      </div>
      <div class="textbox">
        <div class="features">
          <div class="textcontainer">
            <p class="one">N$299 9999</p>
            <p class="two">Manual</p>
            <p class="three">Petrol</p>
            <p class="four">120 000 KM</p>
            <p class="five">2024 Toyota Hilux</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  
   `,
  data() {
    return {
      product: 'Socks',
      brand: 'Vue Mastery',
      selectedVariant: 0,
      details: ['80% cotton', '20% polyester', 'Gender-neutral'],
      variants: [
        {
          id: 2234,
          color: 'green',
          image: './assets/images/socks_green.jpg',
          quantity: 10
        },
        {
          id: 2235,
          color: 'blue',
          image: './assets/images/socks_blue.jpg',
          quantity: 0
        }
      ],
      reviews: [],
      tabs: ['review-form', 'review-list'],
      activeTab: 'review-form'
    }
  },
  methods: {
    addToCart() {
      this.$emit('add-to-cart', this.variants[this.selectedVariant].id)
    },
    updateProduct(index) {
      this.selectedVariant = index
    },
    addReview(review) {
      this.reviews.push(review)
    }
  },
  computed: {
    productName() {
      return this.brand + ' ' + this.product
    },
    image() {
      return this.variants[this.selectedVariant].image
    },
    inStock() {
      return this.variants[this.selectedVariant].quantity
    },
    shipping() {
      if (this.premium) {
        return 'Free'
      }
      return 2.99
    }
  }
})
